// this is the code which will be injected into a given page...

(function() {
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "https://d1x3cbuht6sy0f.cloudfront.net/meeting-app/bundle.js";
  document.head.appendChild(script);
})();
